package com.tsc.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import com.tsc.entity.Feedback;
import com.tsc.entity.TeacherEntity;
import com.tsc.entity.UserEntity;
import com.tsc.model.*;
import com.tsc.service.FeedbackService;
import com.tsc.service.FileUploadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.multipart.MultipartFile;

import org.springframework.web.servlet.mvc.support.RedirectAttributes;


import com.tsc.service.UserService;

@SessionAttributes({ "usr", "userLogin" })
@Controller
public class UserController {

	@Autowired
	private UserService userService;

	@Autowired
	private FileUploadService uploadService;

	@Autowired
	private FeedbackService feedbackService;

	public void setUs(UserService userService) {
		this.userService = userService;
	}


	@GetMapping("/Register")
	public String createreg(Model model) {
		model.addAttribute("user", new User());
		return "user-registration-page";
	}

	
	@GetMapping("/adminhome")
	public String adminhome(Model model) {
		
		return "admin-page";
	}
	
	
	//* SuperAdmin-Approve *//*
	@SuppressWarnings("unused")
	@RequestMapping(value = "/updateStatus")
	public String updateStatus(ModelMap model) {

		List<User> m = userService.Adminid();
		
		model.addAttribute("list", m);
		
		return "superadmin-approve-admin";
	}

	@RequestMapping(value = "/updateStatus/{userId}")
	public String updateStatus(@RequestParam(value="status",required=false) String status,
							   ModelMap model,
							   @PathVariable("userId") String userId) {


		userService.updateStatus(userId, status);

		return "redirect:/updateStatus";
	}


	@RequestMapping(value = "/teacherProfile")
	public String updateStatus(Model model,
							   @SessionAttribute("usr") UserLogin userLogin) {
		TeacherEntity teacherEntity = userService.findTeacher(userLogin.getUserId());
		System.out.println(teacherEntity.toString());
		model.addAttribute("teacher", teacherEntity);
		return "teacher-profile";
	}


	//* Registration values adding to data base *//*
	@RequestMapping(value = "/addtodb", method = RequestMethod.POST)
	public String saveUser(@ModelAttribute("user") User user, Model model,
						   @RequestParam(value = "file", required = false) MultipartFile file) throws IOException {



		String fn = uploadService.storeFile(file);

		String result = userService.saveUser(user);

		if (result.equals("exists"))
			model.addAttribute("msg", "User Id already exists");
		else if (result.equals("success")) {
			model.addAttribute("msg", "Details saved successfully");
		}
		model.addAttribute("userLogin", new UserLogin());
		return "success";

	}

	//* Teacher values adding to database *//*
	@PostMapping(value = "/teacher")
	public String saveteacher(@ModelAttribute("teacher") TeacherEntity teacher) {


		userService.saveteacher(teacher);

		return "redirect:/homeRedirect";
		
	}


    //*login page*//*
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String createLogin(Model model) {
		model.addAttribute("userLogin", new UserLogin());
		return "login";
		
	}

    //*login validation from database*//*
	@RequestMapping(value = "/validate", method = RequestMethod.POST)
	public String validateLogin(@Valid @ModelAttribute("userLogin") UserLogin user, BindingResult bresult,
			ModelMap model, RedirectAttributes redirectAttributes, @SessionAttribute("userLogin") UserLogin usr,
			HttpSession session) {
		String result = "";
		if (bresult.hasErrors()) {
			System.out.println("validation errors");

			return "login";
		}

		else {

			UserLogin u = userService.validateUser(user);
			
			if (u != null) {
				session.setAttribute("usr", u);
				List<String> list = userService.getRole(user.getUserId());
				if (list.get(0).equals("Admin")) {
					if (list.get(1).equals("pending")) {
						redirectAttributes.addFlashAttribute("uname", "You Are Not Approved Yet");
						result = "redirect:login";
					}

					else {
						model.addAttribute("uname", u.getUserId());
						result = "admin-page";

					}
				}

				else if (user.getRole().equals("Teacher")) {
					result = "redirect:teacherpage";
				} else if (user.getRole().equals("Student")) {
					result = "redirect:studenthome";
				} else if (user.getRole().equals("SuperAdmin")) {
					List<User> m = userService.Adminid();
					
					model.addAttribute("list", m);

					result = "redirect:updateStatus";
				}

			}

			else {
				redirectAttributes.addFlashAttribute("uname", "Invalid UserId/password");
				result = "redirect:login";
			}

		}
		return result;
	}

	//*Logout*//*
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logout(@SessionAttribute("usr") UserLogin userLogin, HttpSession session, SessionStatus status) {
		UserEntity userEntity = userService.findUser(userLogin.getUserId());
		if (userEntity.isFeedbackGiven()) {
			status.setComplete();
			session.invalidate();
			return "redirect:/login";
		} else {
			return "redirect:/logoutFeedBack";
		}


	}

	@RequestMapping(value = "/logoutt", method = RequestMethod.GET)
	public String logoutt(HttpSession session, SessionStatus status) {

		status.setComplete();
		session.invalidate();
		return "redirect:/login";

	}

	//*Logout*//*
	@RequestMapping(value = "/passwordRecovery", method = RequestMethod.GET)
	public String showPasswordConfirmation(Model model) {
		model.addAttribute("userPasswordRecovery", new UserPasswordConfirmation());
		return "passwordRecovery";
	}

	@PostMapping(value = "/resetPassword")
	public String resetPass(@ModelAttribute("userPasswordRecovery") UserPasswordConfirmation confirmation, ModelMap model) {

		boolean valid = userService.validateSecretQuestion(confirmation.getSecretQuestion(),
				confirmation.getAnswer(),
				confirmation.getUserId());

		if (!valid) {
			model.put("error", "UserId or answer is not correct");
			return "redirect:/passwordRecovery";
		} else {
			ResetPassword resetPassword = new ResetPassword();
			resetPassword.setUserId(confirmation.getUserId());
			model.put("resetPassword", resetPassword);
			return "resetPassword";
		}

	}

	@PostMapping(value = "/changePassword")
	public String changePassword(@ModelAttribute("resetPassword") ResetPassword resetPassword, ModelMap model) {
		if (!resetPassword.getNewPassword().equals(resetPassword.getNewPasswordConfirmation())) {
			model.put("resetPassword", resetPassword);
			return "resetPassword";
		}
		userService.changePassword(resetPassword);
		return "redirect:/login";

	}

	@GetMapping("/logoutFeedBack")
	public String showLogoutFeedback(Model model, @SessionAttribute("usr") UserLogin userLogin) {
		Feedback feedback = new Feedback();
		feedback.setUserId(userLogin.getUserId());
		model.addAttribute("feedback", feedback);
		return "feedback";
	}


	@PostMapping("/logoutFeedBack")
	public String giveFeedback(@ModelAttribute("feedback") Feedback feedback) {
		feedbackService.addFeedback(feedback);
		return "redirect:/logout";
	}


	@GetMapping("/home")
	public String home(Model model) {
		return "index";
	}

	@RequestMapping("/studenthome")
	public String studenthome() {
		return "student-page";
	}

	@RequestMapping("/teacherpage")
	public String teacherPage() {
		return "teacher-page";
	}

	@RequestMapping("/studentPage")
	public String student() {
		return "studentsort";
	}

	@RequestMapping("/homeRedirect")
	public String redirectToHome(@SessionAttribute("usr") UserLogin userLogin) {
		String role = userLogin.getRole();

		if (role.equals("Admin")) {
			return "redirect:/adminhome";
		} else if (role.equals("Student")){
			return "redirect:/studenthome";
		} else if (role.equals("Teacher")) {
			return "redirect:/teacherpage";
		}

		return "redirect:/home";
	}

	@RequestMapping("/sortByfirstNameAscending")
	public String sortByfirstNameAesc(Model model) {
		List<User> stuList = userService.sortByfirstNameAsc();
		model.addAttribute("stulist", stuList);
		return "studentsort";

	}

	@RequestMapping("/sortByfirstNameDescending")
	public String sortByfirstNameDesc(Model model) {
		List<User> stuList = userService.sortByfirstNameDsc();
		model.addAttribute("stulist", stuList);
		return "studentsort";
	}



}
