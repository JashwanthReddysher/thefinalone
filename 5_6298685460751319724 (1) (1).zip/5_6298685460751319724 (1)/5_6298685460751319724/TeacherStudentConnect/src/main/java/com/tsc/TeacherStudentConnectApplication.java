package com.tsc;

import com.tsc.dao.UserRepository;
import com.tsc.entity.UserEntity;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.FilterType;

@SpringBootApplication
@ComponentScan(basePackages = { "com.tsc" }, excludeFilters = { @ComponentScan.Filter(type = FilterType.ANNOTATION, value = Configuration.class) })
public class TeacherStudentConnectApplication implements ApplicationRunner {

	public static void main(String[] args) {
		SpringApplication.run(TeacherStudentConnectApplication.class, args);
	}

	@Bean
	public ModelMapper modelMapper() {
		return new ModelMapper();
	}

	@Autowired
	private UserRepository userRepository;

	@Override
	public void run(ApplicationArguments args) throws Exception {

		UserEntity userEntity = new UserEntity();
		userEntity.setUserId("SupAdmin");
		userEntity.setPassword("admin");
		userEntity.setRole("SuperAdmin");
		userRepository.save(userEntity);

	}
}
