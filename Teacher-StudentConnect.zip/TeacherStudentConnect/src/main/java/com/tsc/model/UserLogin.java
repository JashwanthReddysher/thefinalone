package com.tsc.model;
public class UserLogin {
	//@NotEmpty(message="userID not present")
	private String userId;
	//@NotEmpty(message="Password not matching")
	private String password;
	
	private String role;
	private String status;
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getPassword() {
		return password;
	}
	
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	

}
