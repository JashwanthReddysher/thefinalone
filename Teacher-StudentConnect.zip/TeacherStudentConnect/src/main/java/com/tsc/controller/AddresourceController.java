package com.tsc.controller;

import java.io.IOException;
import java.io.OutputStream;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import com.tsc.service.FileUploadService;
import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.tsc.entity.AddresourceEntity;

import com.tsc.model.Addskill;
import com.tsc.model.Resources;
import com.tsc.model.Teacher;
import com.tsc.model.Teacherresource;
import com.tsc.model.UserLogin;
import com.tsc.service.AddresourceService;

@Controller
public class AddresourceController {

	@Autowired
	private AddresourceService addresourceService;

	@Autowired
	private FileUploadService fileUploadService;

	@ModelAttribute("addresource")
	public Resources getResources() {
		return new Resources();
	}

	@ModelAttribute("teacherresource")
	public Teacherresource getTeacherresource() {
		return new Teacherresource();
	}
	/* Admin- Add resource */


	@GetMapping(value = "/addresources")
	public String createResource(Model model, @SessionAttribute("userLogin") UserLogin usr) {

		model.addAttribute("addresources", new Resources());
		model.addAttribute("userId", usr.getUserId());
		return "addresources";

	}

	@PostMapping(value = "/resourceadding")
	public String save(@ModelAttribute("resources") Resources resources, @RequestParam("file") MultipartFile file) {



		try {
			String fileName = fileUploadService.storeFile(file);
			resources.setFilename(fileName);
			resources.setContentType(file.getContentType());
			addresourceService.uploadresources(resources);
		} catch (IOException e) {
			e.printStackTrace();
		}

		return "resadded";
	}


	//Admin- View Resource List
	@GetMapping("/resourceList")
	public String getResources1(ModelMap model) {

		List<Resources> r = addresourceService.fetchResources();
		model.addAttribute("resList", r);
		return "resourceList";

	}

	@GetMapping("/showEditResources/{resourceID}")
	public String ResourceDetails(Model model,
								  @PathVariable("resourceID") String resourceID,
								  @SessionAttribute("usr") UserLogin userLogin) {
		Resources resource = addresourceService.getResourceDetails(resourceID);
		if (userLogin.getRole().equals("Admin") || resource.getUserId().equals(userLogin.getUserId())) {
			model.addAttribute("resource", resource);
			return "editResourceList";
		}
		return "redirect:/homeRedirect";
	}

	// Admin- Update resource
	@PostMapping(value = "/update")
	public String updatedetails(@ModelAttribute("resource") Resources resource, @RequestParam("file") MultipartFile file) {

		try {
			String fileName = fileUploadService.storeFile(file);
			resource.setFilename(fileName);
			resource.setContentType(file.getContentType());
			addresourceService.updatedetaiils(resource);
		} catch (IOException e) {
			e.printStackTrace();
		}

		return "redirect:resourceList";
	}

//	 Admin- Add Skills
	@GetMapping(value = "/addskills")
	public String createSkill(Model model, @SessionAttribute("userLogin") UserLogin usr) {
		List<Addskill> list = addresourceService.getresourceid();

		model.addAttribute("command", new Addskill());
		model.addAttribute("addskill", list);
		model.addAttribute("userId", usr.getUserId());
		return "addskills";

	}

//	 Admin- Update skill
	@PostMapping(value = "/updateskill")
	public String updateProduct(@ModelAttribute("res") Addskill res) {

		addresourceService.updateAddskill(res);
		return "resadded";
	}

//	 User- View skill list
	@GetMapping("/skilllist")
	public String getResources2(ModelMap model) {

		List<Resources> r = addresourceService.fetchResources();

		model.addAttribute("resList", r);
		return "skilllist";

	}

	@GetMapping("/showskills/{skill}")
	public String ResourceDetail(Model model, @PathVariable("skill") String skill) {

		List<Addskill> resource = addresourceService.skillsres(skill);
		model.addAttribute("rs", resource);
		return "skillsearch";
	}

	@RequestMapping(value = "/resources", method = RequestMethod.GET)
	public String sortResource(Model model) {

		model.addAttribute("resources", new Resources());

		return "resources";

	}

//	 User- Sorting
	@GetMapping("/documentPage")
	public String document() {
		return "documentList";
	}

	@GetMapping("/sortByYearAscending")
	public String sortByDocumentYearAsc(Model model) {
		List<Resources> docList = addresourceService.sortByYearAsc();
		model.addAttribute("doclist", docList);
		return "documentList";

	}

	@GetMapping("/sortByYearDescending")
	public String sortByDocumentYearDesc(Model model) {
		List<Resources> docList = addresourceService.sortByYearDsc();
		model.addAttribute("doclist", docList);
		return "documentList";

	}

	@GetMapping("/sortByTitleAscending")
	public String sortByDocumentTitleAesc(Model model) {
		List<Resources> docList = addresourceService.sortByTitleAsc();
		model.addAttribute("doclist", docList);
		return "documentList";

	}

	@GetMapping("/sortByTitleDescending")
	public String sortByDocumentTitleDesc(Model model) {
		List<Resources> docList = addresourceService.sortByTitleDsc();
		model.addAttribute("doclist", docList);
		return "documentList";

	}

	@GetMapping("/sortByAuthorAscending")
	public String sortByDocumentAuthorAesc(Model model) {
		List<Resources> docList = addresourceService.sortByAuthorAsc();
		model.addAttribute("doclist", docList);
		return "documentList";

	}

	@GetMapping("/sortByAuthorDescending")
	public String sortByDocumentAuthorDesc(Model model) {
		List<Resources> docList = addresourceService.sortByAuthorDsc();
		model.addAttribute("doclist", docList);
		return "documentList";

	}

	@GetMapping("/sortBySubjectAscending")
	public String sortByDocumentSubjectAesc(Model model) {
		List<Resources> docList = addresourceService.sortBySubjectAsc();
		model.addAttribute("doclist", docList);
		return "documentList";

	}

	@GetMapping("/sortBySubjectDescending")
	public String sortByDocumentSubjectDesc(Model model) {
		List<Resources> docList = addresourceService.sortBySubjectDsc();
		model.addAttribute("doclist", docList);
		return "documentList";

	}

	@GetMapping("/teacherPage")
	public String teacher() {
		return "teachersort";
	}

	@GetMapping("/sortByUserIdAscending")
	public String sortByUserIdAesc(Model model) {
		List<Teacher> teacherList = addresourceService.sortByUserIdAsc();

		model.addAttribute("teacherlist", teacherList);
		return "teachersort";

	}

	@GetMapping("/sortByUserIdDescending")
	public String sortByTeacherUserIdDesc(Model model) {
		List<Teacher> teacherList = addresourceService.sortByUserIdDsc();
		model.addAttribute("teacherlist", teacherList);
		return "teachersort";

	}

	@GetMapping("/sortBySpecializationAscending")
	public String sortByTeacherSpecializationAesc(Model model) {
		List<Teacher> teacherList = addresourceService.sortBySpecializationAsc();
		model.addAttribute("teacherlist", teacherList);
		return "teachersort";

	}

	@GetMapping("/sortBySpecializationDescending")
	public String sortByTeacherSpecializationDesc(Model model) {
		List<Teacher> teacherList = addresourceService.sortBySpecializationDsc();
		model.addAttribute("teacherlist", teacherList);
		return "teachersort";

	}
//	 User- Preview and Download document

	@GetMapping("/download/{resourceID}")
	public String download(@PathVariable("resourceID") String resourceID,
						   HttpServletResponse response) {

		AddresourceEntity doc = addresourceService.downloadResources(resourceID);

		try {

			response.setHeader("Content-Disposition", "inline;title=\"" + doc.getTitle() + "\"");
			OutputStream out = response.getOutputStream();
			response.setContentType(doc.getContentType());
			IOUtils.copy(fileUploadService.loadFile(doc.getFileName()).getInputStream(), out);
			out.flush();
			out.close();

		} catch (IOException e) {
			e.printStackTrace();
		}

		return null;

	}

	@GetMapping(value = "/teacherresource")
	public String showTeacherresource(Model model, @SessionAttribute("userLogin") UserLogin usr) {
		model.addAttribute("resource", new Resources());
		model.addAttribute("userId", usr.getUserId());
		return "teacherresource";
	}

	@RequestMapping(value = "/teacherResources", method = RequestMethod.GET)
	public String createLogin(Model model, @SessionAttribute("usr") UserLogin userLogin ) {
		model.addAttribute("resources", addresourceService.findResourcesByUserId(userLogin.getUserId()));
		return "teacher-resources";

	}
}
