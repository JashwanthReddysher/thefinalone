package com.tsc.service;

import com.tsc.dao.FeedbackRepository;
import com.tsc.dao.UserRepository;
import com.tsc.entity.Feedback;
import com.tsc.entity.UserEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FeedbackService {

    @Autowired
    private FeedbackRepository feedbackRepository;

    @Autowired
    private UserRepository userRepository;

    public void addFeedback(Feedback feedback) {
        UserEntity us = userRepository.findById(feedback.getUserId()).orElseThrow(RuntimeException::new);
        us.setFeedbackGiven(true);
        feedbackRepository.save(feedback);
    }
}
